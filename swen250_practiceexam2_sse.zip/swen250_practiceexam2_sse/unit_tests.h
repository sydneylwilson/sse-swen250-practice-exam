// unit_tests.h

#ifndef UNIT_TESTS_H
#define UNIT_TESTS_H

// main test runner
int test(void);

// simple assert function
int assert(int cond, char *msg);

#endif