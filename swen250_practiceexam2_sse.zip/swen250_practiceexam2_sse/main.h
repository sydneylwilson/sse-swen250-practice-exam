#ifndef MAIN_H
#define MAIN_H

// Entry point for running tests
int main(void);

#endif