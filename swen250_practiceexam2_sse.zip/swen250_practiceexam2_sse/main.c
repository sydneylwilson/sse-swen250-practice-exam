#include <stdio.h>
#include "unit_tests.h"
#include "main.h"

int main(void)
{
    int failures = test();

    if (failures == 0)
    {
        printf("\nAll tests passed!\n");
    }
    else
    {
        printf("\nSome tests failed.\n");
    }

    return failures;
}