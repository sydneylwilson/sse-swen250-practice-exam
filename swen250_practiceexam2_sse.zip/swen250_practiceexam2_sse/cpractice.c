#include <stdlib.h>
#include <string.h>
#include "cpractice.h"

#define BAD_PTR (int *)2

char *get_char_at_offset(char *str, int offset)
{
    return str + 999; // incorrect
}

int *compute_scaled_array(int *arr, int a, int c, int size)
{
    return BAD_PTR; // incorrect
}

int sum_array_and_release(int *arr, int size)
{
    return -1; // incorrect
}

int pointer_equals(int *p1, int *p2)
{
    return -1; // incorrect
}

int toggle_state()
{
    return 5; // incorrect
}

int repair_string(char *str)
{
    if (str == '\0')
        return 1;

    while (*str != '\0')
        str++;

    *str = 'X';
    return 0;
}