#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cpractice.h"

int assert(int cond, char *msg)
{
    static int test_num = 1;
    if (!cond)
    {
        printf("Test %d failed: %s\n", test_num, msg);
        test_num++;
        return 0;
    }
    test_num++;
    return 1;
}

int test()
{
    int pass = 0, fail = 0;

    char str[] = "hello";

    // get_char_at_offset
    assert(get_char_at_offset(str, 0) == str, "offset 0 failed") ? pass++ : fail++;
    assert(get_char_at_offset(str, 2) == str + 2, "offset 2 failed") ? pass++ : fail++;
    assert(get_char_at_offset(str, 10) == NULL, "out of bounds failed") ? pass++ : fail++;

    // compute_scaled_array
    int x[] = {1, 2, 3};
    int expected[] = {3, 5, 7};

    int *y = compute_scaled_array(x, 2, 1, 3);
    assert(y != NULL, "allocation failed") ? pass++ : fail++;
    assert(memcmp(y, expected, sizeof(expected)) == 0, "values incorrect") ? pass++ : fail++;

    // sum_array_and_release
    assert(sum_array_and_release(NULL, 3) == 0, "NULL case failed") ? pass++ : fail++;
    assert(sum_array_and_release(y, 3) == 15, "sum incorrect") ? pass++ : fail++;

    // pointer_equals
    assert(pointer_equals(x, x) == 1, "same pointer failed") ? pass++ : fail++;
    assert(pointer_equals(x, &x[1]) == 0, "different pointer failed") ? pass++ : fail++;

    // toggle_state
    assert(toggle_state() == 0, "first toggle failed") ? pass++ : fail++;
    assert(toggle_state() == 1, "second toggle failed") ? pass++ : fail++;
    assert(toggle_state() == 0, "third toggle failed") ? pass++ : fail++;

    // repair_string
    char test_str[] = "abc";
    assert(repair_string(test_str) == 1, "repair return failed") ? pass++ : fail++;
    assert(test_str[0] == 'X', "repair modification failed") ? pass++ : fail++;

    printf("\nPassed: %d\nFailed: %d\n", pass, fail);
    return fail;
}